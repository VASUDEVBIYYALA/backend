package com.hotel.mangment;

public class Customer extends Person {
	int roomid;
	Room room;
	 public Customer(int id,String name,String phno,Room room) {
		 super(id,name,phno);
		 this.room=room;
	 }
	 public void rentroom() {
		 this.roomid=room.getRoomid();
	 }
	@Override
	public void show() {
		System.out.println("********customer deteils*********");
		System.out.println("\t customer id :"+super.id);
		System.out.println("\t customer name :"+super.name);
		System.out.println("\t customer phno :"+super.phno);
		System.out.println("\t customer roomid :"+roomid);
		
		// TODO Auto-generated method stub
		
	}
	


}
