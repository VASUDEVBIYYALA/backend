package com.hotel.mangment;

public abstract class Person {
	

	
	int id;
	String name;
	String phno;
	
	public Person(int id,String name,String phno) {
		this.id=id;
		this.name=name;
		this.phno=phno;
		
	}
	
	public abstract void show(); 
		

}
