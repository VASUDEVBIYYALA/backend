package com.hotel.mangment;

public class Mainhotel {
	public static void main(String[] args) {
		Deluxroom dr = new Deluxroom(123, "32a", 15444.22, 4555.25);
		Standardroom sr = new Standardroom(654, "12d", 23000.25, true);
		Customer cs = new Customer(400, "vasu", "9004040", dr);
		cs.rentroom();
		cs.show();
		}

}
