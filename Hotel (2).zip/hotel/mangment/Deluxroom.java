package com.hotel.mangment;

public class Deluxroom extends Room{
	
	double roomsize;
	
	public Deluxroom(int roomid,String roomno,double roomfare,double roomsize) 
	{
		super(roomid,roomno,roomfare);
		this.roomsize=roomsize;
		
	}

	@Override
	public void roominfo() {
		System.out.println("***delux room");
		System.out.println("roomid"+super.roomid);
		System.out.println("room number"+super.roomno);
		System.out.println("room price"+super.roomfare);
		System.out.println("room size"+this.roomsize);
		// TODO Auto-generated method stub
		
		// TODO Auto-generated method stub
		
	}

}
