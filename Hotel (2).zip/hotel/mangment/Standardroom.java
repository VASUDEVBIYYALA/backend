package com.hotel.mangment;

public class Standardroom extends Room{
	boolean ac_aval;
	public Standardroom(int roomid,String roomno,Double roomfare,boolean ac_aval)
	{
		super(roomid,roomno,roomfare);
		this.ac_aval=ac_aval;
	}
	@Override
	public void roominfo() {
		
		System.out.println("****standard room");
		System.out.println("roomid"+super.roomid);
		System.out.println("room number"+super.roomno);
		System.out.println("room price"+super.roomfare);
		System.out.println("ac avaliablity"+this.ac_aval);
		// TODO Auto-generated method stub
		
	}
	
	
	

}
