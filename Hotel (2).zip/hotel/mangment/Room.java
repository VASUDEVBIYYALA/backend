package com.hotel.mangment;

public abstract class Room {
	//initialization
	int roomid;
	String roomno;
	double roomfare;
	//parametrized constcructors
	public Room(int roomid,String roomno,Double roomfare) {
		this.roomid=roomid;
		this.roomno=roomno;
		this.roomfare=roomfare;
	}
	//getter and setters
	public int getRoomid() {
		return roomid;
	}

	public void setRoomid(int roomid) {
		this.roomid = roomid;
	}

	public String getRoomno() {
		return roomno;
	}

	public void setRoomno(String roomno) {
		this.roomno = roomno;
	}

	public double getRoomfare() {
		return roomfare;
	}

	public void setRoomfare(double roomfare) {
		this.roomfare = roomfare;
	}

	public abstract void roominfo();

}
